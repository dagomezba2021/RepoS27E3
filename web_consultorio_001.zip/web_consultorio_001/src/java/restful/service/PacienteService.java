package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Moldel.PacienteModel;
import restful.Moldel.Conexion;
import restful.Moldel.PacienteModel;

public class PacienteService {

    public ArrayList<PacienteModel> getPacientes() {
        ArrayList<PacienteModel> lista = new ArrayList<>();
        Conexion conn = new Conexion();
        String sql = "SELECT * FROM Paciente";

        try {
            Statement stm = conn.getCon().createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                PacienteModel paciente = new PacienteModel();
                paciente.setID_Documento_identidad_Paciente(rs.getInt("ID_Documento_identidad_Paciente"));
                paciente.setprimer_nombre(rs.getString("primer_nombre"));
                paciente.setsegundo_nombre(rs.getString("segundo_nombre"));
                paciente.setfecha_nacimiento(rs.getString("fecha_nacimiento"));
                paciente.setcorreo_electronico(rs.getString("correo_electronicod"));
                paciente.settelefono_fijo(rs.getString("telefono_fijo"));
                paciente.settelefono_celular(rs.getString("telefono_celular"));
                paciente.setgenero(rs.getString("genero"));
                paciente.setcontrasena_paciente(rs.getString("contrasena_paciente"));
                lista.add(paciente);
            }
        } catch (SQLException e) {
        }

        return lista;
    }

}
