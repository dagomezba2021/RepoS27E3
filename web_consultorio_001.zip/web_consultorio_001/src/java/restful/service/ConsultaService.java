/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restful.service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Moldel.ConsultaModel;
import restful.Moldel.Conexion;


public class ConsultaService {
    
    
     public ArrayList<ConsultaModel> getConsultas() {
        ArrayList<ConsultaModel> lista = new ArrayList<>();
        Conexion conn = new Conexion();
        String sql = "SELECT * FROM Consulta";

        try {
            Statement stm = conn.getCon().createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                ConsultaModel consulta = new ConsultaModel();
                consulta.setID_consulta(rs.getInt("ID_consulta"));
                consulta.setID_Documento_identidad_Paciente(rs.getInt("ID_Documento_identidad_Paciente"));
                
                
                lista.add(consulta);
            }
        } catch (SQLException e) {
        }

        return lista;
    }

    public ConsultaModel getConsulta(int id) {
        ConsultaModel consulta = new ConsultaModel();
        Conexion conex = new Conexion();
        String Sql = "SELECT * FROM consulta WHERE id_consulta = ?";

        try {

            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setInt(1, id);
            ResultSet rs = pstm.executeQuery();

            while (rs.next()) {
                
                consulta.setID_consulta(rs.getInt("ID_consulta"));
                consulta.setID_Documento_identidad_Paciente(rs.getInt("ID_Documento_identidad_Paciente"));
                
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return consulta;
    }
    
    public ConsultaModel addConsulta(ConsultaModel consulta) {
        Conexion conex = new Conexion();
        String Sql = "INSERT INTO cliente(ID_consulta,ID_Documento_identidad_Paciente)";
        Sql = Sql + "values (?,?,?)";

        try {
            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setInt(1, consulta.getID_consulta());
            pstm.setInt(2, consulta.getID_Documento_identidad_Paciente());
           
            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
        return consulta;
    }
    
     public ConsultaModel updateConsulta(ConsultaModel consulta) {
        Conexion conn = new Conexion();
        String sql = "UPDATE consulta SET ID_Documento_identidad_Paciente=? WHERE ID_consulta= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setInt(1, consulta.getID_Documento_identidad_Paciente());
            pstm.setInt(2, consulta.getID_consulta());
            
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al eliminar  " + excepcion.getMessage());
            return null;
        }
        return consulta;
    }
      public String delConsulta(int id) {
        Conexion conn = new Conexion();

        String sql = "DELETE FROM consulta WHERE ID_consulta= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setInt(1, id);
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al eliminar  " + excepcion.getMessage());
            return "{\"Accion\":\"Error\"}";
        }
        return "{\"Accion\":\"Registro Borrado\"}";
    }
    
    
    
}
