
package restful.Moldel;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement


public class ConsultaModel {
    private int  ID_consulta; 
    private int  ID_Documento_identidad_Paciente;     

    public ConsultaModel() {
    }
    public ConsultaModel(int ID_consulta, int ID_Documento_identidad_Paciente) {
        this.ID_consulta = ID_consulta;
        this.ID_Documento_identidad_Paciente = ID_Documento_identidad_Paciente;
    }

    public int getID_consulta() {
        return ID_consulta;
    }

    public void setID_consulta(int ID_consulta) {
        this.ID_consulta = ID_consulta;
    }

    public int getID_Documento_identidad_Paciente() {
        return ID_Documento_identidad_Paciente;
    }

    public void setID_Documento_identidad_Paciente(int ID_Documento_identidad_Paciente) {
        this.ID_Documento_identidad_Paciente = ID_Documento_identidad_Paciente;
    }
    
    
    
}
