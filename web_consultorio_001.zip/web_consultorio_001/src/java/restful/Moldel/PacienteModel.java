
package restful.Moldel;
import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PacienteModel {
    private int ID_Documento_identidad_Paciente;
    private String primer_nombre;
    private String segundo_nombre;
    private String fecha_nacimiento;
    private String correo_electronico;
    private String telefono_fijo;
    private String telefono_celular;
    private String genero;
    private String contrasena_paciente;

    public PacienteModel() {
    }

    public PacienteModel(int ID_Documento_identidad_Paciente, String primer_nombre,String segundo_nombre, String fecha_nacimiento, String correo_electronico, String telefono_fijo, String telefono_celular, String genero,String contrasena_paciente ) {
        this.ID_Documento_identidad_Paciente = ID_Documento_identidad_Paciente;
        this.primer_nombre = primer_nombre;
        this.segundo_nombre= segundo_nombre;
        this.fecha_nacimiento=fecha_nacimiento;
        this.correo_electronico = correo_electronico;
        this.telefono_fijo = telefono_fijo;
        this.telefono_celular = telefono_celular;
        this.genero=genero;
        this.contrasena_paciente=contrasena_paciente;
    }

    public int getID_Documento_identidad_Paciente() {
        return ID_Documento_identidad_Paciente;
    }

    public void setID_Documento_identidad_Paciente(int ID_Documento_identidad_Paciente) {
        this.ID_Documento_identidad_Paciente = ID_Documento_identidad_Paciente;
    }

    public String getprimer_nombre() {
        return primer_nombre;
       
    }

    public void setprimer_nombre(String primer_nombre) {
        this.primer_nombre = primer_nombre;
    }
       
    
    public String getsegundo_nombre() {
        return segundo_nombre;
    }
    
    public void setsegundo_nombre(String segundo_nombre) {
        this.segundo_nombre=segundo_nombre;
    }  
    
    public String getfecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setfecha_nacimiento(String fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getcorreo_electronico() {
        return correo_electronico;
    }

    public void setcorreo_electronico(String correo_electronico) {
        this.correo_electronico = correo_electronico;
    }

    public String gettelefono_fijo() {
        return telefono_fijo;
    }

    public void settelefono_fijo(String telefono_fijo) {
        this.telefono_fijo = telefono_fijo;
    }
    
    public String gettelefono_celular(){
        return telefono_celular;    
    }
    public void settelefono_celular(String telefono_celular){
        this.telefono_celular = telefono_celular;
    }
    
    public String getgenero(){
        return genero;
    }
    public void setgenero(String genero){
        this.genero= genero;
    }
    
    public String getcontrasena_paciente(){
        return contrasena_paciente;
    }
    
    public void setcontrasena_paciente(String contrasena_paciente){
        this.contrasena_paciente = contrasena_paciente;
    }

    public void add(PacienteModel Paciente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    

}