
package restful.resource;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Moldel.ConsultaModel;
import restful.service.ConsultaService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;



@Path("consultas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ConsultaResource {
    
    
    
    ConsultaService servicio = new ConsultaService();
    
    @GET
    public ArrayList<ConsultaModel> getConsultas() {

        return servicio.getConsultas();
    }
    
    @Path("/{ConsultaId}")
    @GET
    public ConsultaModel getConsulta(@PathParam("ConsultaId") int id) {

        return servicio.getConsulta(id);
    }
    
    @POST
    public ConsultaModel addConsulta(String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        ConsultaModel consulta = gson.fromJson(JSON, ConsultaModel.class);
        return servicio.addConsulta(consulta);
    }
    
   

    @PUT
    public ConsultaModel updateConsulta(String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        ConsultaModel consulta = gson.fromJson(JSON, ConsultaModel.class);
        return servicio.updateConsulta(consulta);
    }
    
    @DELETE
    @Path("/{ConsultaId}")
    public String delConsulta(@PathParam("ConsutlaId") int id) {

        return servicio.delConsulta(id);

    }
    
    
}
